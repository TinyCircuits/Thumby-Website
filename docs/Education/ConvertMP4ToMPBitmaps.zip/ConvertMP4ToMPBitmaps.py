import cv2

print("Started")

video = cv2.VideoCapture('DancingAnimation-edited.mp4')
success, image = video.read()
frameCount = 0

EXPECTED_WIDTH = 72
EXPECTED_HEIGHT = 40
WHITE_THRESHOLD = 200

file = open("video.raw", 'wb')

while success:
    height, width, channels = image.shape
    frameBytes = []

    for y in range(0, EXPECTED_HEIGHT, 8):
        for x in range(0, EXPECTED_WIDTH, 1):
            byte = 0b00000000
            for i in range(0, 8, 1):
                if image[y+i, x, 0] > WHITE_THRESHOLD or image[y+i, x, 1] > WHITE_THRESHOLD or image[y+i, x, 2] > WHITE_THRESHOLD:
                    byte = byte | (1 << i)
                else:
                    byte = byte & ~(1 << i)
            frameBytes.append(byte)

    file.write(bytes(bytearray(frameBytes)))

    success, image = video.read()
    frameCount += 1
    print('Read a new frame: ', frameCount)

file.close()

print("")
print("Ended:")
print("   Frame count: ", frameCount)
print("   Total frame bytes (kB): ", (frameCount * 360)/1000)

print("")
print("############################################")
print("")
print("Data output to: video.raw")
print("")